// CRUD create read update delete

// const mongodb = require('mongodb')
// const MongoClient = mongodb.MongoClient

const {MongoClient,ObjectId}=require('mongodb')

const connectionURL = 'mongodb://127.0.0.1:27017'
const databaseName = 'task-manager'
const id=new ObjectId()

console.log(id)
//gettimestamp it will return date and time 
console.log(id.getTimestamp())
 console.log(id.toHexString().length)
MongoClient.connect(connectionURL, { useNewUrlParser: true }, (error, client) => {
    if (error) {
        return console.log('Unable to connect to database!')
    }

    const db = client.db(databaseName)
   //------READ----//

    //   db.collection('users').findOne({name:'Rayan'},(error,user)=>{
    //       if(error){
    //           console.log(error)
    //       }
    //       console.log(user)
    //   })

        // db.collection('users').find({age:23}).toArray((error,user)=>{
        //     if(error){
        //         console.log(error)
        //     }
        //     console.log(user)
        // })

        // db.collection('users').find({age:23}).count((error,count)=>{
        //     console.log(count)
        // })
  
        //-----INSERT---//
 
    // db.collection('users').insertOne({
    //     _id:id,
    //     name: 'vikram',
    //     age:34
    // },(error,result)=>{
    //     if(error){
    //         console.log(error)
    //     }
    //     console.log(result.ops)
    // })
    // db.collection('users').insertOne({
    //     name: 'Rayan',
    //     age: 27
    // },(error,result)=>{
    //     if(error){
    //         console.log(error)
    //     }
    //     console.log(result.ops)
    // })

    // db.collection('users').insertMany([{
    //       name:'ayan',
    //       age:34
    // },{
    //      name:'black panther',
    //      age:23
    // }],(error,result)=>{
    //     if(error){
    //         console.log(error)
    //     }
    //     console.log(result.ops)
    // })

    // db.collection('task').insertMany([{
    //       description:'work at office',
    //       completed:'true'
    // },{
    //     description:'work at home',
    //     completed:'false'
    // }],(error,result)=>{
    //     if(error){
    //         console.log(error)
    //     }
    //     console.log(result.ops)
    // })

    // db.collection('task').findOne({_id:new ObjectId("5e54cf300d5e0d2144db6638")},(error,task)=>{
    //     console.log('task'+JSON.stringify(task))
    // })
    // db.collection('task').find({completed:'false'}).toArray((error,task)=>{
    //           console.log(task)
    // })

//   db.collection('users').updateOne({
//                _id:new ObjectId("5e54c4009aebc10aa8e077ab")

//     },{
//         $set:{
//                name:'Abhinav'
//         }
//     }).then((result)=>{
//         console.log(result)
//     }).catch((error)=>{
//          console.log(error);
         
//     }
//     )
//    db.collection('users').updateOne({
//        _id:new ObjectId("5e54c4009aebc10aa8e077ab")
//    },{
//        $inc:{
//            age:3
//        }
//    }).then((result)=>{
//        console.log(result)
//    }).catch((error)=>{
//        console.log(error)
//    })
})
